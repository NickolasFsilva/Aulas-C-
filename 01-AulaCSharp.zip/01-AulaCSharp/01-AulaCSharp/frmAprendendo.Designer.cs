﻿
namespace _01_AulaCSharp
{
    partial class frmAprendendo
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAprendendo));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.grpEscolha = new System.Windows.Forms.GroupBox();
            this.chkMySQL = new System.Windows.Forms.CheckBox();
            this.chkCSharp = new System.Windows.Forms.CheckBox();
            this.chkSQL = new System.Windows.Forms.CheckBox();
            this.grpQuerAprenderCSharp = new System.Windows.Forms.GroupBox();
            this.chkNao = new System.Windows.Forms.CheckBox();
            this.chkSim = new System.Windows.Forms.CheckBox();
            this.grpCadastro = new System.Windows.Forms.GroupBox();
            this.lbSenha = new System.Windows.Forms.Label();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lbNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblLinguagens1 = new System.Windows.Forms.Label();
            this.cbbLinguagens = new System.Windows.Forms.ComboBox();
            this.mskFone = new System.Windows.Forms.MaskedTextBox();
            this.lblFone = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.mskData = new System.Windows.Forms.MaskedTextBox();
            this.dgvTeste = new System.Windows.Forms.DataGridView();
            this.lblLinguagens = new System.Windows.Forms.Label();
            this.tabBanco = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.lblLogin = new System.Windows.Forms.Label();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.lblExplicação = new System.Windows.Forms.Label();
            this.toolStripSalvar = new System.Windows.Forms.ToolStripButton();
            this.toolStripAltrar = new System.Windows.Forms.ToolStripButton();
            this.toolStripExcluir = new System.Windows.Forms.ToolStripButton();
            this.toolStripCancelar = new System.Windows.Forms.ToolStripButton();
            this.toolStripLogout = new System.Windows.Forms.ToolStripButton();
            this.toolStripSair = new System.Windows.Forms.ToolStripButton();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnCuidado = new System.Windows.Forms.Button();
            this.btnAtencao = new System.Windows.Forms.Button();
            this.btnOla = new System.Windows.Forms.Button();
            this.grpEscolha.SuspendLayout();
            this.grpQuerAprenderCSharp.SuspendLayout();
            this.grpCadastro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeste)).BeginInit();
            this.tabBanco.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(-1, 54);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(216, 31);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Aprendendo C#";
            this.lblTitulo.Click += new System.EventHandler(this.lblTitulo_Click);
            // 
            // grpEscolha
            // 
            this.grpEscolha.Controls.Add(this.chkMySQL);
            this.grpEscolha.Controls.Add(this.chkCSharp);
            this.grpEscolha.Controls.Add(this.chkSQL);
            this.grpEscolha.Location = new System.Drawing.Point(145, 97);
            this.grpEscolha.Name = "grpEscolha";
            this.grpEscolha.Size = new System.Drawing.Size(74, 107);
            this.grpEscolha.TabIndex = 6;
            this.grpEscolha.TabStop = false;
            this.grpEscolha.Text = "Escolha";
            // 
            // chkMySQL
            // 
            this.chkMySQL.AutoSize = true;
            this.chkMySQL.Location = new System.Drawing.Point(6, 63);
            this.chkMySQL.Name = "chkMySQL";
            this.chkMySQL.Size = new System.Drawing.Size(64, 17);
            this.chkMySQL.TabIndex = 2;
            this.chkMySQL.Text = "My SQL";
            this.chkMySQL.UseVisualStyleBackColor = true;
            this.chkMySQL.CheckedChanged += new System.EventHandler(this.chkMySQL_CheckedChanged);
            // 
            // chkCSharp
            // 
            this.chkCSharp.AutoSize = true;
            this.chkCSharp.Location = new System.Drawing.Point(6, 40);
            this.chkCSharp.Name = "chkCSharp";
            this.chkCSharp.Size = new System.Drawing.Size(40, 17);
            this.chkCSharp.TabIndex = 1;
            this.chkCSharp.Text = "C#";
            this.chkCSharp.UseVisualStyleBackColor = true;
            this.chkCSharp.CheckedChanged += new System.EventHandler(this.chkCSharp_CheckedChanged);
            // 
            // chkSQL
            // 
            this.chkSQL.AutoSize = true;
            this.chkSQL.Location = new System.Drawing.Point(6, 17);
            this.chkSQL.Name = "chkSQL";
            this.chkSQL.Size = new System.Drawing.Size(47, 17);
            this.chkSQL.TabIndex = 0;
            this.chkSQL.Text = "SQL";
            this.chkSQL.UseVisualStyleBackColor = true;
            this.chkSQL.CheckedChanged += new System.EventHandler(this.chkSQL_CheckedChanged);
            // 
            // grpQuerAprenderCSharp
            // 
            this.grpQuerAprenderCSharp.Controls.Add(this.chkNao);
            this.grpQuerAprenderCSharp.Controls.Add(this.chkSim);
            this.grpQuerAprenderCSharp.Location = new System.Drawing.Point(225, 97);
            this.grpQuerAprenderCSharp.Name = "grpQuerAprenderCSharp";
            this.grpQuerAprenderCSharp.Size = new System.Drawing.Size(120, 107);
            this.grpQuerAprenderCSharp.TabIndex = 7;
            this.grpQuerAprenderCSharp.TabStop = false;
            this.grpQuerAprenderCSharp.Text = "Quer Aprender C# ?";
            // 
            // chkNao
            // 
            this.chkNao.AutoSize = true;
            this.chkNao.Location = new System.Drawing.Point(3, 73);
            this.chkNao.Name = "chkNao";
            this.chkNao.Size = new System.Drawing.Size(46, 17);
            this.chkNao.TabIndex = 1;
            this.chkNao.Text = "Não";
            this.chkNao.UseVisualStyleBackColor = true;
            this.chkNao.CheckedChanged += new System.EventHandler(this.chkNao_CheckedChanged);
            // 
            // chkSim
            // 
            this.chkSim.AutoSize = true;
            this.chkSim.Location = new System.Drawing.Point(3, 50);
            this.chkSim.Name = "chkSim";
            this.chkSim.Size = new System.Drawing.Size(43, 17);
            this.chkSim.TabIndex = 0;
            this.chkSim.Text = "Sim";
            this.chkSim.UseVisualStyleBackColor = true;
            this.chkSim.CheckedChanged += new System.EventHandler(this.chkSim_CheckedChanged);
            // 
            // grpCadastro
            // 
            this.grpCadastro.Controls.Add(this.lblLogin);
            this.grpCadastro.Controls.Add(this.txtLogin);
            this.grpCadastro.Controls.Add(this.mskData);
            this.grpCadastro.Controls.Add(this.lblData);
            this.grpCadastro.Controls.Add(this.lblFone);
            this.grpCadastro.Controls.Add(this.mskFone);
            this.grpCadastro.Controls.Add(this.lbSenha);
            this.grpCadastro.Controls.Add(this.txtSenha);
            this.grpCadastro.Controls.Add(this.lbEmail);
            this.grpCadastro.Controls.Add(this.txtEmail);
            this.grpCadastro.Controls.Add(this.lbNome);
            this.grpCadastro.Controls.Add(this.txtNome);
            this.grpCadastro.Location = new System.Drawing.Point(146, 210);
            this.grpCadastro.Name = "grpCadastro";
            this.grpCadastro.Size = new System.Drawing.Size(199, 251);
            this.grpCadastro.TabIndex = 8;
            this.grpCadastro.TabStop = false;
            this.grpCadastro.Text = "Cadastro";
            // 
            // lbSenha
            // 
            this.lbSenha.AutoSize = true;
            this.lbSenha.Location = new System.Drawing.Point(4, 96);
            this.lbSenha.Name = "lbSenha";
            this.lbSenha.Size = new System.Drawing.Size(38, 13);
            this.lbSenha.TabIndex = 5;
            this.lbSenha.Text = "Senha";
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(6, 111);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '*';
            this.txtSenha.Size = new System.Drawing.Size(178, 20);
            this.txtSenha.TabIndex = 4;
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.Location = new System.Drawing.Point(4, 56);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(32, 13);
            this.lbEmail.TabIndex = 3;
            this.lbEmail.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(6, 71);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(178, 20);
            this.txtEmail.TabIndex = 2;
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Location = new System.Drawing.Point(5, 20);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(35, 13);
            this.lbNome.TabIndex = 1;
            this.lbNome.Text = "Nome";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(7, 35);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(177, 20);
            this.txtNome.TabIndex = 0;
            // 
            // lblLinguagens1
            // 
            this.lblLinguagens1.AutoSize = true;
            this.lblLinguagens1.Location = new System.Drawing.Point(351, 254);
            this.lblLinguagens1.Name = "lblLinguagens1";
            this.lblLinguagens1.Size = new System.Drawing.Size(62, 13);
            this.lblLinguagens1.TabIndex = 9;
            this.lblLinguagens1.Text = "Linguagens";
            // 
            // cbbLinguagens
            // 
            this.cbbLinguagens.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbLinguagens.FormattingEnabled = true;
            this.cbbLinguagens.Items.AddRange(new object[] {
            "HTML",
            "CSS",
            "Javascript",
            "PHP",
            "C#"});
            this.cbbLinguagens.Location = new System.Drawing.Point(351, 270);
            this.cbbLinguagens.Name = "cbbLinguagens";
            this.cbbLinguagens.Size = new System.Drawing.Size(121, 21);
            this.cbbLinguagens.TabIndex = 10;
            this.cbbLinguagens.SelectedIndexChanged += new System.EventHandler(this.cbbLinguagens_SelectedIndexChanged);
            // 
            // mskFone
            // 
            this.mskFone.Location = new System.Drawing.Point(5, 150);
            this.mskFone.Mask = "(00) 00000-0000";
            this.mskFone.Name = "mskFone";
            this.mskFone.Size = new System.Drawing.Size(179, 20);
            this.mskFone.TabIndex = 6;
            // 
            // lblFone
            // 
            this.lblFone.AutoSize = true;
            this.lblFone.Location = new System.Drawing.Point(7, 132);
            this.lblFone.Name = "lblFone";
            this.lblFone.Size = new System.Drawing.Size(31, 13);
            this.lblFone.TabIndex = 7;
            this.lblFone.Text = "Fone";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(7, 174);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(30, 13);
            this.lblData.TabIndex = 8;
            this.lblData.Text = "Data";
            // 
            // mskData
            // 
            this.mskData.Location = new System.Drawing.Point(5, 188);
            this.mskData.Mask = "00/00/0000";
            this.mskData.Name = "mskData";
            this.mskData.Size = new System.Drawing.Size(179, 20);
            this.mskData.TabIndex = 9;
            // 
            // dgvTeste
            // 
            this.dgvTeste.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTeste.Location = new System.Drawing.Point(354, 101);
            this.dgvTeste.Name = "dgvTeste";
            this.dgvTeste.Size = new System.Drawing.Size(434, 150);
            this.dgvTeste.TabIndex = 11;
            // 
            // lblLinguagens
            // 
            this.lblLinguagens.Location = new System.Drawing.Point(493, 270);
            this.lblLinguagens.Name = "lblLinguagens";
            this.lblLinguagens.Size = new System.Drawing.Size(100, 23);
            this.lblLinguagens.TabIndex = 12;
            // 
            // tabBanco
            // 
            this.tabBanco.Controls.Add(this.tabPage1);
            this.tabBanco.Controls.Add(this.tabPage2);
            this.tabBanco.Location = new System.Drawing.Point(351, 358);
            this.tabBanco.Name = "tabBanco";
            this.tabBanco.SelectedIndex = 0;
            this.tabBanco.Size = new System.Drawing.Size(437, 125);
            this.tabBanco.TabIndex = 13;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(429, 99);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "SQL Server";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(429, 99);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "My SQL";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "O SQL Server é um Banco de dados da Microsoft";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "O My SQL é o Banco de dados da Oracle";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSalvar,
            this.toolStripAltrar,
            this.toolStripExcluir,
            this.toolStripCancelar,
            this.toolStripLogout,
            this.toolStripSair});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(832, 54);
            this.toolStrip1.TabIndex = 14;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // lblLogin
            // 
            this.lblLogin.AutoSize = true;
            this.lblLogin.Location = new System.Drawing.Point(5, 211);
            this.lblLogin.Name = "lblLogin";
            this.lblLogin.Size = new System.Drawing.Size(33, 13);
            this.lblLogin.TabIndex = 11;
            this.lblLogin.Text = "Login";
            this.lblLogin.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtLogin
            // 
            this.txtLogin.Location = new System.Drawing.Point(5, 227);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(177, 20);
            this.txtLogin.TabIndex = 10;
            this.txtLogin.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblExplicação
            // 
            this.lblExplicação.AutoSize = true;
            this.lblExplicação.Location = new System.Drawing.Point(566, 254);
            this.lblExplicação.Name = "lblExplicação";
            this.lblExplicação.Size = new System.Drawing.Size(177, 117);
            this.lblExplicação.TabIndex = 15;
            this.lblExplicação.Text = resources.GetString("lblExplicação.Text");
            // 
            // toolStripSalvar
            // 
            this.toolStripSalvar.Image = global::_01_AulaCSharp.Properties.Resources.save_32;
            this.toolStripSalvar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSalvar.Name = "toolStripSalvar";
            this.toolStripSalvar.Size = new System.Drawing.Size(42, 51);
            this.toolStripSalvar.Text = "Salvar";
            this.toolStripSalvar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripSalvar.Click += new System.EventHandler(this.toolStripSalvar_Click);
            // 
            // toolStripAltrar
            // 
            this.toolStripAltrar.Image = global::_01_AulaCSharp.Properties.Resources.update_321;
            this.toolStripAltrar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.toolStripAltrar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripAltrar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripAltrar.Name = "toolStripAltrar";
            this.toolStripAltrar.Size = new System.Drawing.Size(46, 51);
            this.toolStripAltrar.Text = "Alterar";
            this.toolStripAltrar.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            this.toolStripAltrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripExcluir
            // 
            this.toolStripExcluir.Image = global::_01_AulaCSharp.Properties.Resources.delete_32;
            this.toolStripExcluir.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripExcluir.Name = "toolStripExcluir";
            this.toolStripExcluir.Size = new System.Drawing.Size(46, 51);
            this.toolStripExcluir.Text = "Excluir";
            this.toolStripExcluir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripExcluir.Click += new System.EventHandler(this.toolStripExcluir_Click);
            // 
            // toolStripCancelar
            // 
            this.toolStripCancelar.Image = global::_01_AulaCSharp.Properties.Resources.cancel_32;
            this.toolStripCancelar.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripCancelar.Name = "toolStripCancelar";
            this.toolStripCancelar.Size = new System.Drawing.Size(57, 51);
            this.toolStripCancelar.Text = "Cancelar";
            this.toolStripCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripCancelar.Click += new System.EventHandler(this.toolStripCancelar_Click);
            // 
            // toolStripLogout
            // 
            this.toolStripLogout.Image = global::_01_AulaCSharp.Properties.Resources.logout_32;
            this.toolStripLogout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripLogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripLogout.Name = "toolStripLogout";
            this.toolStripLogout.Size = new System.Drawing.Size(49, 51);
            this.toolStripLogout.Text = "Logout";
            this.toolStripLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // toolStripSair
            // 
            this.toolStripSair.Image = global::_01_AulaCSharp.Properties.Resources.exit_32;
            this.toolStripSair.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripSair.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSair.Name = "toolStripSair";
            this.toolStripSair.Size = new System.Drawing.Size(36, 51);
            this.toolStripSair.Text = "Sair";
            this.toolStripSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripSair.Click += new System.EventHandler(this.toolStripSair_Click);
            // 
            // picFoto
            // 
            this.picFoto.Image = global::_01_AulaCSharp.Properties.Resources.csharp;
            this.picFoto.Location = new System.Drawing.Point(32, 364);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(107, 97);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFoto.TabIndex = 5;
            this.picFoto.TabStop = false;
            // 
            // btnSair
            // 
            this.btnSair.Image = global::_01_AulaCSharp.Properties.Resources.sair;
            this.btnSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSair.Location = new System.Drawing.Point(32, 308);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(107, 51);
            this.btnSair.TabIndex = 4;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnCuidado
            // 
            this.btnCuidado.Image = global::_01_AulaCSharp.Properties.Resources.cuidado;
            this.btnCuidado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCuidado.Location = new System.Drawing.Point(32, 235);
            this.btnCuidado.Name = "btnCuidado";
            this.btnCuidado.Size = new System.Drawing.Size(107, 51);
            this.btnCuidado.TabIndex = 3;
            this.btnCuidado.Text = "Cuidado";
            this.btnCuidado.UseVisualStyleBackColor = true;
            this.btnCuidado.Click += new System.EventHandler(this.btnCuidado_Click);
            // 
            // btnAtencao
            // 
            this.btnAtencao.Image = global::_01_AulaCSharp.Properties.Resources.atencao;
            this.btnAtencao.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAtencao.Location = new System.Drawing.Point(32, 169);
            this.btnAtencao.Name = "btnAtencao";
            this.btnAtencao.Size = new System.Drawing.Size(107, 51);
            this.btnAtencao.TabIndex = 2;
            this.btnAtencao.Text = "Atenção";
            this.btnAtencao.UseVisualStyleBackColor = true;
            this.btnAtencao.Click += new System.EventHandler(this.btnAtencao_Click);
            // 
            // btnOla
            // 
            this.btnOla.Image = global::_01_AulaCSharp.Properties.Resources.ola;
            this.btnOla.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOla.Location = new System.Drawing.Point(32, 103);
            this.btnOla.Name = "btnOla";
            this.btnOla.Size = new System.Drawing.Size(107, 51);
            this.btnOla.TabIndex = 1;
            this.btnOla.Text = "Olá";
            this.btnOla.UseVisualStyleBackColor = true;
            this.btnOla.Click += new System.EventHandler(this.btnOla_Click);
            // 
            // frmAprendendo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 481);
            this.Controls.Add(this.lblExplicação);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.tabBanco);
            this.Controls.Add(this.lblLinguagens);
            this.Controls.Add(this.dgvTeste);
            this.Controls.Add(this.cbbLinguagens);
            this.Controls.Add(this.lblLinguagens1);
            this.Controls.Add(this.grpCadastro);
            this.Controls.Add(this.grpQuerAprenderCSharp);
            this.Controls.Add(this.grpEscolha);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnCuidado);
            this.Controls.Add(this.btnAtencao);
            this.Controls.Add(this.btnOla);
            this.Controls.Add(this.lblTitulo);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAprendendo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " Aprendendo C#";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAprendendo_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpEscolha.ResumeLayout(false);
            this.grpEscolha.PerformLayout();
            this.grpQuerAprenderCSharp.ResumeLayout(false);
            this.grpQuerAprenderCSharp.PerformLayout();
            this.grpCadastro.ResumeLayout(false);
            this.grpCadastro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTeste)).EndInit();
            this.tabBanco.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnOla;
        private System.Windows.Forms.Button btnAtencao;
        private System.Windows.Forms.Button btnCuidado;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.GroupBox grpEscolha;
        private System.Windows.Forms.CheckBox chkMySQL;
        private System.Windows.Forms.CheckBox chkCSharp;
        private System.Windows.Forms.CheckBox chkSQL;
        private System.Windows.Forms.GroupBox grpQuerAprenderCSharp;
        private System.Windows.Forms.CheckBox chkNao;
        private System.Windows.Forms.CheckBox chkSim;
        private System.Windows.Forms.GroupBox grpCadastro;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lbSenha;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lblLinguagens1;
        private System.Windows.Forms.ComboBox cbbLinguagens;
        private System.Windows.Forms.MaskedTextBox mskData;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblFone;
        private System.Windows.Forms.MaskedTextBox mskFone;
        private System.Windows.Forms.DataGridView dgvTeste;
        private System.Windows.Forms.Label lblLinguagens;
        private System.Windows.Forms.TabControl tabBanco;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripSalvar;
        private System.Windows.Forms.Label lblLogin;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.Label lblExplicação;
        private System.Windows.Forms.ToolStripButton toolStripAltrar;
        private System.Windows.Forms.ToolStripButton toolStripExcluir;
        private System.Windows.Forms.ToolStripButton toolStripCancelar;
        private System.Windows.Forms.ToolStripButton toolStripLogout;
        private System.Windows.Forms.ToolStripButton toolStripSair;
    }
}

