﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _01_AulaCSharp
{
    public partial class frmAprendendo : Form
    {
        public frmAprendendo()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Adicionando itens no combobox
            cbbLinguagens.Items.Add("Java");
            cbbLinguagens.Items.Add("JQuery");
            cbbLinguagens.Items.Add("Pear");

            // Adicionando as colunas no DataGrig

            dgvTeste.Columns.Add("codigo", "Codigo");
            dgvTeste.Columns.Add("nome", "Nome");
            dgvTeste.Columns.Add("preco", "Preço");
            dgvTeste.Columns.Add("data", "Data");

            // Alinhando as colunas

            dgvTeste.Columns["codigo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvTeste.Columns["preco"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            // Laço para preencher as linhas do DataGrid

            for (int cont = 0; cont <= 100; cont++)
            {
                // Cria uma linha

                DataGridViewRow item = new DataGridViewRow();
                item.CreateCells(dgvTeste);

                // Seta os valores
                item.Cells[0].Value = cont;
                item.Cells[1].Value = "Produto " + cont;
                item.Cells[2].Value = 10.50;
                item.Cells[3].Value = DateTime.Today;

                // Adiciona as linhas no DataGrid

                dgvTeste.Rows.Add(item);
            }
        }

        private void btnOla_Click(object sender, EventArgs e)
        {
            // Caixa de mensagem: mensagem, titulo, botão e icone
            MessageBox.Show("Olá usuario, seja bem vindo(a)!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnAtencao_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Atenção!!!\n Não falte nas aulas de C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }

        private void btnCuidado_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cuidado!!!\nNão faça cocozinho no codigo", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
           
            {
                Application.Exit();
            
            }
        }

        private void frmAprendendo_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult Sair = MessageBox.Show("Deseja sair do programa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Sair == DialogResult.No)
            {
                e.Cancel = true;

            }
        }

        private void chkSQL_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSQL.Checked == true)
            {
                MessageBox.Show("Você marcou o SQL Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
                else
            {
                MessageBox.Show("Você desmarcou o SQL Server", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void chkCSharp_CheckedChanged(object sender, EventArgs e)
        {

            if (chkCSharp.Checked == true)
            {
                MessageBox.Show("Você marcou C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou o C#", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkMySQL_CheckedChanged(object sender, EventArgs e)
        {

            if (chkMySQL.Checked == true)
            {
                MessageBox.Show("Você marcou My SQL", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Você desmarcou My SQL", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkSim_CheckedChanged(object sender, EventArgs e)
        {

            if (chkSim.Checked == true)
            {
                MessageBox.Show("Legal, vamos começar", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void chkNao_CheckedChanged(object sender, EventArgs e)
        {
            if (chkNao.Checked == true)
            {
                MessageBox.Show("Putz....", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cbbLinguagens_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Label recebe o texto do combobox

            lblLinguagens.Text = cbbLinguagens.Text;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblTitulo_Click(object sender, EventArgs e)
        {

        }

        private void toolStripSalvar_Click(object sender, EventArgs e)
        {
            toolStripCancelar.Visible = true;
            toolStripSalvar.Enabled = false;
        }

        private void toolStripExcluir_Click(object sender, EventArgs e)
        {

        }

        private void toolStripCancelar_Click(object sender, EventArgs e)
        {
            toolStripCancelar.Visible = false;
            toolStripSalvar.Enabled = true;
        }

        private void toolStripSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }

}

