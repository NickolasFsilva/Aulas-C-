﻿using _06_CRUD.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _06_CRUD.Telas
{
    public partial class frmUsuario : Form
    {
        Usuario usuarioLogado = new Usuario();
        public frmUsuario(Usuario usu)
        {
            InitializeComponent();
            usuarioLogado = usu;
        }

        private void frmUsuario_Load(object sender, EventArgs e)
        {
            dgvUsuariosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
            dgvUsuariosAtivados.Columns[0].Visible = false;
            dgvUsuariosAtivados.Columns[1].HeaderText = "Nome";
            dgvUsuariosAtivados.Columns[2].HeaderText = "E-mail";
            dgvUsuariosAtivados.Columns[3].Visible = false;
            dgvUsuariosAtivados.Columns[4].Visible = false;
            dgvUsuariosAtivados.Columns[5].HeaderText = "Nível";
            dgvUsuariosAtivados.Columns[6].Visible = false;
            dgvUsuariosAtivados.Columns[7].Visible = false;

            dgvUsuariosDesativados.DataSource = Usuario.BuscarTodosUsuariosDesativados();
            dgvUsuariosDesativados.Columns[0].Visible = false;
            dgvUsuariosDesativados.Columns[1].HeaderText = "Nome";
            dgvUsuariosDesativados.Columns[2].HeaderText = "E-mail";
            dgvUsuariosDesativados.Columns[3].Visible = false;
            dgvUsuariosDesativados.Columns[4].Visible = false;
            dgvUsuariosDesativados.Columns[5].HeaderText = "Nível";
            dgvUsuariosDesativados.Columns[6].Visible = false;
            dgvUsuariosDesativados.Columns[7].Visible = false;
        }

        private void dgvUsuariosDesativados_DoubleClick(object sender, EventArgs e)
        {
            if (dgvUsuariosDesativados.SelectedRows.Count > 0)
            {
                int id = Convert.ToInt32(dgvUsuariosDesativados.SelectedRows[0].Cells[0].Value.ToString());
                DialogResult Pergunta = MessageBox.Show("Deseja reativar esse usuário?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (Pergunta == DialogResult.Yes)
                {
                    try
                    {
                        Usuario Ativar = new Usuario(id, 1);
                        Ativar.AtivarUsuario();
                        MessageBox.Show("Usuário ativado!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        toolStripSalvar.Enabled = true;
                        toolStripAtualizar.Enabled = false;
                        toolStripExcluir.Enabled = false;
                        toolStripCancelar.Visible = false;
                        LimpaDados();
                        dgvUsuariosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
                        dgvUsuariosDesativados.DataSource = Usuario.BuscarTodosUsuariosDesativados();
                    }
                    catch (Exception)
                    {

                        throw;
                    }
                }
            }
            

        }


        private void LimpaDados()
        {
            txbId.Clear();
            txbNome.Clear();
            txbEmail.Clear();
            txbLogin.Clear();
            txbNome.Focus();
            cbbNivel.SelectedIndex = -1;
            dgvUsuariosAtivados.DefaultCellStyle.SelectionBackColor = Color.CornflowerBlue;
            dgvUsuariosDesativados.DefaultCellStyle.SelectionBackColor = Color.CornflowerBlue;
        }

        private void dgvUsuariosAtivados_Click(object sender, EventArgs e)
        {
            MostraUsuario();
        }

        private void MostraUsuario()
        {
            if (dgvUsuariosAtivados.SelectedRows.Count > 0)
            {
                txbId.Text = dgvUsuariosAtivados.SelectedRows[0].Cells[0].Value.ToString();
                txbNome.Text = dgvUsuariosAtivados.SelectedRows[0].Cells[1].Value.ToString();
                txbEmail.Text = dgvUsuariosAtivados.SelectedRows[0].Cells[2].Value.ToString();
                txbLogin.Text = dgvUsuariosAtivados.SelectedRows[0].Cells[7].Value.ToString();
                cbbNivel.SelectedIndex = Convert.ToInt32(dgvUsuariosAtivados.SelectedRows[0].Cells[5].Value.ToString());
                toolStripSalvar.Enabled = false;
                toolStripAtualizar.Enabled = true;
                toolStripExcluir.Enabled = true;
                toolStripCancelar.Visible = true;
                dgvUsuariosAtivados.DefaultCellStyle.SelectionBackColor = Color.Tomato;
            }
        }

        private void toolStripSalvar_Click(object sender, EventArgs e)
        {
            if (ValidaDados())
            {

                if (Usuario.VerificaLogin(txbLogin.Text) && Usuario.VerificaEmail(txbEmail.Text))
                {


                string senhaCrypto = Crypto.sha256encrypt("123");
                senhaCrypto = senhaCrypto.ToLower();
                string frase = "padrão";

                Usuario Novousuario = new Usuario(txbNome.Text, txbEmail.Text, txbLogin.Text, senhaCrypto, frase, cbbNivel.SelectedIndex, 1);
                Novousuario.InsereUsuario();
                MessageBox.Show("Usuario inserido!", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LimpaDados();
                    dgvUsuariosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();

                }
            }
        }

        private bool ValidaDados()
        {
            if (txbNome.Text == string.Empty)
            {
                MessageBox.Show("Digite o nome", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbNome.Focus();
                return false;
            }

            if (txbNome.Text == string.Empty)
            {
                MessageBox.Show("Digite o Email", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbEmail.Focus();
                return false;
            }

            if (txbNome.Text == string.Empty)
            {
                MessageBox.Show("Digite o Login", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txbLogin.Focus();
                return false;
            }
            if (txbNome.Text == string.Empty)
            {
                MessageBox.Show("Digite o seu Nivel de acesso", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cbbNivel.Focus();
                return false;
            }

            return true;
        }

        private void toolStripAtualizar_Click(object sender, EventArgs e)
        {
            if (ValidaDados())
            {
                Usuario Altera = new Usuario(int.Parse(txbId.Text), txbNome.Text, txbEmail.Text, txbLogin.Text, cbbNivel.SelectedIndex);
                Altera.AlteraUsuario();
                MessageBox.Show("Usuario alterado", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpaDados();
                dgvUsuariosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
                toolStripSalvar.Enabled = true;
                toolStripAtualizar.Enabled = false;
                toolStripExcluir.Enabled = false;
                toolStripCancelar.Visible = false;
            }
        }

        private void toolStripExcluir_Click(object sender, EventArgs e)
        {
            DialogResult Pergunta = MessageBox.Show("Deseja excluir esta pessoa?", "Aviso", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Pergunta == DialogResult.Yes)
            {
                Usuario Deletar = new Usuario(int.Parse(txbId.Text, 0), txbNome.Text, txbEmail.Text, txbLogin.Text, cbbNivel.SelectedIndex);
                Deletar.DesativarUsuario();
                toolStripCancelar.PerformClick();
                dgvUsuariosAtivados.DataSource = Pessoa.BuscaTodasPessoas();
                MessageBox.Show("Pessoa excluída", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dgvUsuariosAtivados.DataSource = Usuario.BuscarTodosUsuariosAtivados();
                dgvUsuariosDesativados.DataSource = Usuario.BuscarTodosUsuariosDesativados();
            }
        }
    }
}
