﻿
namespace _04_Tabuada
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskNumero = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pdbUm = new System.Windows.Forms.RadioButton();
            this.pdbDois = new System.Windows.Forms.RadioButton();
            this.pdbTres = new System.Windows.Forms.RadioButton();
            this.pdbQuatro = new System.Windows.Forms.RadioButton();
            this.pdbCinco = new System.Windows.Forms.RadioButton();
            this.pdbDez = new System.Windows.Forms.RadioButton();
            this.pdbNove = new System.Windows.Forms.RadioButton();
            this.pdbOito = new System.Windows.Forms.RadioButton();
            this.pdbSete = new System.Windows.Forms.RadioButton();
            this.pdbSeis = new System.Windows.Forms.RadioButton();
            this.lstResultado = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mskNumero
            // 
            this.mskNumero.Location = new System.Drawing.Point(13, 39);
            this.mskNumero.Mask = "00";
            this.mskNumero.Name = "mskNumero";
            this.mskNumero.Size = new System.Drawing.Size(21, 20);
            this.mskNumero.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Digite um numero";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(230, 24);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(103, 52);
            this.btnCalcular.TabIndex = 2;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(339, 24);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(100, 52);
            this.btnLimpar.TabIndex = 3;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pdbDez);
            this.groupBox1.Controls.Add(this.pdbNove);
            this.groupBox1.Controls.Add(this.pdbOito);
            this.groupBox1.Controls.Add(this.pdbSete);
            this.groupBox1.Controls.Add(this.pdbSeis);
            this.groupBox1.Controls.Add(this.pdbCinco);
            this.groupBox1.Controls.Add(this.pdbQuatro);
            this.groupBox1.Controls.Add(this.pdbTres);
            this.groupBox1.Controls.Add(this.pdbDois);
            this.groupBox1.Controls.Add(this.pdbUm);
            this.groupBox1.Location = new System.Drawing.Point(12, 182);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(122, 283);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // pdbUm
            // 
            this.pdbUm.AutoSize = true;
            this.pdbUm.Location = new System.Drawing.Point(7, 45);
            this.pdbUm.Name = "pdbUm";
            this.pdbUm.Size = new System.Drawing.Size(31, 17);
            this.pdbUm.TabIndex = 0;
            this.pdbUm.TabStop = true;
            this.pdbUm.Text = "1";
            this.pdbUm.UseVisualStyleBackColor = true;
            this.pdbUm.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // pdbDois
            // 
            this.pdbDois.AutoSize = true;
            this.pdbDois.Location = new System.Drawing.Point(6, 99);
            this.pdbDois.Name = "pdbDois";
            this.pdbDois.Size = new System.Drawing.Size(31, 17);
            this.pdbDois.TabIndex = 1;
            this.pdbDois.TabStop = true;
            this.pdbDois.Text = "2";
            this.pdbDois.UseVisualStyleBackColor = true;
            this.pdbDois.CheckedChanged += new System.EventHandler(this.pdbDois_CheckedChanged);
            // 
            // pdbTres
            // 
            this.pdbTres.AutoSize = true;
            this.pdbTres.Location = new System.Drawing.Point(7, 155);
            this.pdbTres.Name = "pdbTres";
            this.pdbTres.Size = new System.Drawing.Size(31, 17);
            this.pdbTres.TabIndex = 2;
            this.pdbTres.TabStop = true;
            this.pdbTres.Text = "3";
            this.pdbTres.UseVisualStyleBackColor = true;
            this.pdbTres.CheckedChanged += new System.EventHandler(this.pdbTres_CheckedChanged);
            // 
            // pdbQuatro
            // 
            this.pdbQuatro.AutoSize = true;
            this.pdbQuatro.Location = new System.Drawing.Point(7, 203);
            this.pdbQuatro.Name = "pdbQuatro";
            this.pdbQuatro.Size = new System.Drawing.Size(31, 17);
            this.pdbQuatro.TabIndex = 3;
            this.pdbQuatro.TabStop = true;
            this.pdbQuatro.Text = "4";
            this.pdbQuatro.UseVisualStyleBackColor = true;
            this.pdbQuatro.CheckedChanged += new System.EventHandler(this.rdbQuatro_CheckedChanged);
            // 
            // pdbCinco
            // 
            this.pdbCinco.AutoSize = true;
            this.pdbCinco.Location = new System.Drawing.Point(7, 251);
            this.pdbCinco.Name = "pdbCinco";
            this.pdbCinco.Size = new System.Drawing.Size(31, 17);
            this.pdbCinco.TabIndex = 4;
            this.pdbCinco.TabStop = true;
            this.pdbCinco.Text = "5";
            this.pdbCinco.UseVisualStyleBackColor = true;
            this.pdbCinco.CheckedChanged += new System.EventHandler(this.pdbCinco_CheckedChanged);
            // 
            // pdbDez
            // 
            this.pdbDez.AutoSize = true;
            this.pdbDez.Location = new System.Drawing.Point(60, 251);
            this.pdbDez.Name = "pdbDez";
            this.pdbDez.Size = new System.Drawing.Size(37, 17);
            this.pdbDez.TabIndex = 9;
            this.pdbDez.TabStop = true;
            this.pdbDez.Text = "10";
            this.pdbDez.UseVisualStyleBackColor = true;
            this.pdbDez.CheckedChanged += new System.EventHandler(this.pdbDez_CheckedChanged);
            // 
            // pdbNove
            // 
            this.pdbNove.AutoSize = true;
            this.pdbNove.Location = new System.Drawing.Point(66, 203);
            this.pdbNove.Name = "pdbNove";
            this.pdbNove.Size = new System.Drawing.Size(31, 17);
            this.pdbNove.TabIndex = 8;
            this.pdbNove.TabStop = true;
            this.pdbNove.Text = "9";
            this.pdbNove.UseVisualStyleBackColor = true;
            this.pdbNove.CheckedChanged += new System.EventHandler(this.pdbNove_CheckedChanged);
            // 
            // pdbOito
            // 
            this.pdbOito.AutoSize = true;
            this.pdbOito.Location = new System.Drawing.Point(66, 155);
            this.pdbOito.Name = "pdbOito";
            this.pdbOito.Size = new System.Drawing.Size(31, 17);
            this.pdbOito.TabIndex = 7;
            this.pdbOito.TabStop = true;
            this.pdbOito.Text = "8";
            this.pdbOito.UseVisualStyleBackColor = true;
            this.pdbOito.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // pdbSete
            // 
            this.pdbSete.AutoSize = true;
            this.pdbSete.Location = new System.Drawing.Point(66, 99);
            this.pdbSete.Name = "pdbSete";
            this.pdbSete.Size = new System.Drawing.Size(31, 17);
            this.pdbSete.TabIndex = 6;
            this.pdbSete.TabStop = true;
            this.pdbSete.Text = "7";
            this.pdbSete.UseVisualStyleBackColor = true;
            this.pdbSete.CheckedChanged += new System.EventHandler(this.pdbSete_CheckedChanged);
            // 
            // pdbSeis
            // 
            this.pdbSeis.AutoSize = true;
            this.pdbSeis.Location = new System.Drawing.Point(66, 45);
            this.pdbSeis.Name = "pdbSeis";
            this.pdbSeis.Size = new System.Drawing.Size(31, 17);
            this.pdbSeis.TabIndex = 5;
            this.pdbSeis.TabStop = true;
            this.pdbSeis.Text = "6";
            this.pdbSeis.UseVisualStyleBackColor = true;
            this.pdbSeis.CheckedChanged += new System.EventHandler(this.pdbSeis_CheckedChanged);
            // 
            // lstResultado
            // 
            this.lstResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstResultado.FormattingEnabled = true;
            this.lstResultado.ItemHeight = 31;
            this.lstResultado.Location = new System.Drawing.Point(218, 183);
            this.lstResultado.Name = "lstResultado";
            this.lstResultado.Size = new System.Drawing.Size(221, 376);
            this.lstResultado.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 616);
            this.Controls.Add(this.lstResultado);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.mskNumero);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskNumero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton pdbCinco;
        private System.Windows.Forms.RadioButton pdbQuatro;
        private System.Windows.Forms.RadioButton pdbTres;
        private System.Windows.Forms.RadioButton pdbDois;
        private System.Windows.Forms.RadioButton pdbUm;
        private System.Windows.Forms.RadioButton pdbDez;
        private System.Windows.Forms.RadioButton pdbNove;
        private System.Windows.Forms.RadioButton pdbOito;
        private System.Windows.Forms.RadioButton pdbSete;
        private System.Windows.Forms.RadioButton pdbSeis;
        private System.Windows.Forms.ListBox lstResultado;
    }
}

