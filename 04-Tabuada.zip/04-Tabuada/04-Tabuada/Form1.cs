﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _04_Tabuada
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 1;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 8;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void rdbQuatro_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 4;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (Verifica())
            {
                int numero = int.Parse(mskNumero.Text);
                lstResultado.Items.Clear();
                for (int i = 1; i <= 10; i++)
                {
                    lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
                }
            }
        }

        public bool Verifica()
        {
            if (mskNumero.Text == string.Empty)
	        {
                MessageBox.Show("Digite o numero", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                mskNumero.Focus();
                return false;
            }

            return true;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskNumero.Clear();
            pdbUm.Checked = false;
            pdbDois.Checked = false;
            pdbTres.Checked = false;
            pdbQuatro.Checked = false;
            pdbCinco.Checked = false;
            pdbSeis.Checked = false;
            pdbSete.Checked = false;
            pdbOito.Checked = false;
            pdbNove.Checked = false;
            pdbDez.Checked = false;
            lstResultado.Items.Clear();
            mskNumero.Focus();

        }

        private void pdbDois_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 2;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void pdbTres_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 3;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void pdbCinco_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 5;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void pdbSeis_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 6;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void pdbSete_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 7;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void pdbNove_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 9;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }

        private void pdbDez_CheckedChanged(object sender, EventArgs e)
        {
            int numero = 10;
            lstResultado.Items.Clear();
            for (int i = 1; i <= 10; i++)
            {
                lstResultado.Items.Add(numero + " X " + i + " = " + (numero * i));
            }
        }
    }
}
